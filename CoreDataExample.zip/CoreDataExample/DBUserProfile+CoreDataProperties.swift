//
//  DBUserProfile+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by Manuel Mosso on 6/15/17.
//  Copyright © 2017 Manuel Mosso. All rights reserved.
//

import Foundation
import CoreData

extension DBUserProfile {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DBUserProfile> {
        return NSFetchRequest<DBUserProfile>(entityName: "DBUserProfile")
    }

    @NSManaged public var name: String?
    @NSManaged public var password: String?
    @NSManaged public var age: Int32
    @NSManaged public var isLogged: Bool
    @NSManaged public var image: NSData?

}



