

//
//  DBUserProfile+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Manuel Mosso on 6/15/17.
//  Copyright © 2017 Manuel Mosso. All rights reserved.
//

import Foundation
import CoreData

@objc(DBUserProfile)
public class DBUserProfile: NSManagedObject {

}




