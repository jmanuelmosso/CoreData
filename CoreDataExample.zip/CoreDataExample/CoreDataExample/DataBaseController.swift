//
//  DataBaseController.swift
//  CoreDataExample
//
//  Created by Manuel Mosso on 6/15/17.
//  Copyright © 2017 Manuel Mosso. All rights reserved.
//

import Foundation
import CoreData
import UIKit

public class DataBaseController
{
	init(){}

	// MARK: - DB Entity Names
	private let dbUserProfileClassName:String = String(describing: DBUserProfile.self)
	
	
	// MARK: - Core Data Engine Methods
	
	//Core Data Context
	private class func getContext() -> NSManagedObjectContext {
		return DataBaseController.persistentContainer.viewContext
	}
	
	//Core Data stack
	static var persistentContainer: NSPersistentContainer = {
		let container = NSPersistentContainer(name: "DBModel")
		container.loadPersistentStores(completionHandler: { (storeDescription, error) in
			if let error = error as NSError? {
				fatalError("Unresolved error \(error), \(error.userInfo)")
			}
		})
		return container
	}()
	
	//Core Data Saving support
	class func saveContext () {
		let context = persistentContainer.viewContext
		if context.hasChanges {
			do {
				try context.save()
			} catch {
				let nserror = error as NSError
				fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
			}
		}
	}
	
	
	// MARK: - DB Operations
	
	public func insertUser(user: User)-> Void
	{
	
		
	}
	
	
	public func getAllUsers()-> [User]
	{
		let allUsers: [User] = [User]()
		
		
		return allUsers
	}
	
	
	public func getUserByName() -> User?
	{
		let user: User = User()
		
		
	
		return user
	}
	
	
	private func getLoggedUser()-> Void
	{
		
		
	}
	
	
	private func updateUserData() -> Void
	{
	
		
		
	}
	
	

	
}



