//
//  User.swift
//  CoreDataExample
//
//  Created by Manuel Mosso on 6/16/17.
//  Copyright © 2017 Manuel Mosso. All rights reserved.
//

import Foundation
import UIKit

public class User
{
	 var name: String
	 var password: String
	 var age: Int
	 var image: UIImage
	
	init(name: String, password: String, age: Int, image: UIImage) {
		self.name = name
		self.password = password
		self.age = age
		self.image = image
	}
	
	convenience init(){
	let defaultImage: UIImage = UIImage(named: "default")!
	self.init(name: "User not exist", password: "Empty", age: 0, image: defaultImage)
	}
}


