//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Manuel Mosso on 6/15/17.
//  Copyright © 2017 Manuel Mosso. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

	
	// Outlets
	@IBOutlet weak var inputName: UITextField!
	@IBOutlet weak var inputPassword: UITextField!
	@IBOutlet weak var inputAge: UITextField!
	@IBOutlet weak var inputImageName: UITextField!
	
	@IBOutlet weak var outputName: UILabel!
	@IBOutlet weak var outputAge: UILabel!
	@IBOutlet weak var outputUsers: UITextView!
	
	@IBOutlet weak var profileImage: UIImageView!
	
	
	//Database
	var db: DataBaseController = DataBaseController()
	
	
	override func viewDidLoad() {
		super.viewDidLoad()
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()

	}

	
	
	@IBAction func insertUser(_ sender: UIButton) {
		

		
	}
	
	@IBAction func getAllUsers(_ sender: UIButton) {
	
	
	}
	
	
	@IBAction func getUserByName(_ sender: UIButton) {
		
		
	}
	
	
	
	
	
	
	
	

}

